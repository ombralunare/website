upon("allReady").then(function()
{
    alert("hello world")
})
